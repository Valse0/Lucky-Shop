# 02 — Player Save Backup and Recovery

## Objective
Protect existing player progress during code changes, schema migration, and reset flows.

## Required safeguards
1. Identify the exact current localStorage key(s) and save format before editing.
2. Preserve the original raw save before migration or transformation.
3. Use a versioned migration path for known older schemas.
4. Never silently replace malformed, unknown, or newer-schema data with a fresh save.
5. If migration fails, retain the original raw value and report a recoverable error.
6. Keep reset progress as an explicit player action, separate from migration or validation.
7. Do not modify or clear save data during app startup merely to make parsing succeed.

## Backup approach
Use the simplest reliable mechanism compatible with the existing app:
- Before a migration, copy the raw serialized save to a versioned backup key or an existing backup mechanism.
- Avoid unbounded backup accumulation; define a small, documented retention policy.
- Do not overwrite the only known-good backup with an unverified migrated save.
- If browser storage quota or write failure prevents backup, abort the destructive migration and preserve the original value.

## Recovery behavior
- Provide a safe, understandable error state if the save cannot be loaded.
- Do not automatically start a new save when existing data is present but unreadable.
- Where practical, offer a controlled recovery path that can restore the preserved backup.
- Never expose raw save contents or internal errors unnecessarily in the player UI.

## Test scenarios
- Valid current save loads with all progress unchanged.
- Known older save migrates and preserves Gold, Gems, level, shop level, missions, statistics, and relevant settings.
- Malformed JSON does not cause silent data loss.
- Invalid fields are handled according to explicit validation rules.
- Unknown/newer schema remains untouched.
- Simulated storage write failure does not destroy the original save.
- Migration interrupted between backup and commit remains recoverable.
- Explicit player reset still works when no spin is active.

## Acceptance
A migration or validation failure must never silently wipe or overwrite the player's only existing progress.
