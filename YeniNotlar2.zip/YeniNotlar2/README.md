# Lucky Shop — Additional Quality Gates (Pack 2)

This is a **supplement** to `YeniNotlar.zip`, not a replacement for it.

Upload both archives to the repository and instruct the implementation agent to read:
1. `YeniNotlar/README.md` (from Pack 1)
2. `YeniNotlar2/README.md` (this supplement)

The decisions in Pack 1 remain authoritative. This pack adds three cross-cutting quality requirements:
- Visual regression checks.
- Player-save backup and recovery safeguards.
- Mobile performance verification.

Do not duplicate or reinterpret the approved gameplay/economy decisions. Apply these requirements alongside the original implementation brief.
