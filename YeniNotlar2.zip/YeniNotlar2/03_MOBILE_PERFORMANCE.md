# 03 — Mobile Performance and Animation Budget

## Objective
Improve visual polish without making the portrait game sluggish, especially on mid-range Android devices and mobile browsers.

## Performance review
Inspect the existing implementation before optimizing. Do not rewrite working systems based on assumptions.

Check:
- Unnecessary React state updates and rerenders during reel animation.
- Expensive effects that run continuously while idle.
- Large images and duplicate asset loading.
- Layout shifts during spin and modal transitions.
- Excessive blur, shadow, filter, and compositing layers.
- Event listeners and animation loops that are not cleaned up.
- Memory growth after repeated spins and screen changes.

## Animation requirements
- Keep the current reel sequence and gameplay timing unless a correctness or usability issue requires change.
- Avoid continuous animation when the game is idle.
- Prefer transform/opacity-based animation where suitable.
- Stop or clean up animation work when components unmount or the page becomes inactive.
- Respect `prefers-reduced-motion`.
- Keep ordinary wins restrained and reserve stronger effects for meaningful wins.
- Do not block the next valid interaction longer than the existing game design requires.

## Asset requirements
- Inspect actual asset dimensions and file sizes.
- Reuse existing assets where appropriate.
- Do not delete or overwrite assets as an optimization shortcut.
- Do not add large new libraries for minor visual effects.
- Do not load source asset ZIP archives into the runtime bundle.
- If an asset is oversized, report the proposed optimization and preserve the original source file.

## Device and viewport checks
At minimum, verify:
- A narrow portrait viewport.
- A common modern mobile portrait viewport.
- A larger phone viewport.
- Safe-area insets where supported.
- The main Spin and BET controls remain visible and responsive.
- Modals remain readable and usable without clipping.

If physical-device testing is unavailable, state that clearly and provide the exact manual test steps. Do not claim real-device performance has been verified from desktop-only testing.

## Acceptance
- No obvious input lag during spin.
- No runaway CPU/GPU work while idle.
- No progressive slowdown after repeated spins.
- No layout overflow or clipped primary controls on supported portrait sizes.
- Reduced-motion mode remains functional.
- Any unverified device-specific claims are explicitly labeled.
