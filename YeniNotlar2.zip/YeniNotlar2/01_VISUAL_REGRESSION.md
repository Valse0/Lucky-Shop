# 01 — Visual Regression and Screenshot Review

## Objective
Prevent a visual improvement on one screen from unintentionally damaging another screen or state.

## Required baseline
Before visual changes:
- Run the current app if the repository can be built.
- Capture baseline screenshots at consistent viewport dimensions and device scale.
- Record the browser/device, viewport size, and relevant game state for each capture.
- Use the supplied reference and current screenshots where available.

## Minimum screen coverage
Capture and compare:
1. Main Shop / slot screen.
2. Rewards screen.
3. Leaderboard screen.
4. Paytable.
5. Settings and confirmation modals.
6. Royal Slots in locked and unlocked states.
7. Slot states: idle, spinning, stopped with no win, ordinary win, and major win if reproducible.

## Review criteria
Compare before/after captures for:
- Layout and alignment.
- Text legibility and clipping.
- Symbol clarity, color, and proportions.
- Cabinet/control-panel cohesion.
- Safe-area and navigation visibility.
- Modal sizing and scrolling.
- Locked/unlocked state correctness.
- Consistency with the approved preserved visual identity.

## Automation
If the project already has screenshot or browser-test tooling, extend it rather than adding a heavy new stack.
If no screenshot tooling exists, use a lightweight documented manual capture process. Do not add a large dependency solely for screenshot comparison without explaining the trade-off.

Pixel-perfect diffs are not mandatory where animation, fonts, or rendering vary. Use side-by-side review and mask genuinely dynamic regions where appropriate.

## Acceptance
- No unrelated screen regresses.
- No text is clipped or made unreadable.
- The primary portrait layout remains usable.
- The cat, sign, symbol family, and existing identity remain recognizable.
- Any intentional visual differences are documented.
