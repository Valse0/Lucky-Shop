# Skill: Lucky Shop Visual and Gameplay Integration

When working on Lucky Shop:
1. Read the master prompt and design/asset rules.
2. Audit before editing.
3. Preserve the existing stack and user changes.
4. Select assets based on actual visual inspection, not ZIP size or filename alone.
5. Use a central symbol manifest and paytable.
6. Keep RNG/outcome logic independent from animation.
7. Use the supplied reel motion helper as a reference implementation; adapt it safely.
8. Validate the final reel state against the precomputed outcome.
9. Compare screenshots against the user's reference at the same aspect ratio.
10. Update changelog and report exact tests.
