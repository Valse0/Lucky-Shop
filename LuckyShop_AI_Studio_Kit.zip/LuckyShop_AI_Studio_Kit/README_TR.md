# Lucky Shop — AI Studio Geliştirme Kiti

Bu paket, mevcut GitHub reposuna bağlanan AI Studio'ya verilecek proje sözleşmesini, oyun tasarımını, asset kurallarını, görev sırasını ve slot makarası animasyon yardımcı kodunu içerir.

## Kullanım

1. ZIP'i açıp içeriğini mevcut repo köküne kopyala. Mevcut dosyaların üzerine körlemesine yazma; aynı isimde dosya varsa önce karşılaştır.
2. Referans ekran görüntüsünü AI Studio konuşmasına ayrıca yükle.
3. `MASTER_PROMPT_TR.md` içeriğini AI Studio'ya gönder.
4. AI Studio'dan önce yalnızca analiz raporu ve uygulama planı iste. Onayından sonra aşamalı uygulamaya geç.
5. `src/slot/slotMotion.ts` dosyası framework bağımsız makara hareket yardımcısıdır. AI Studio mevcut teknolojiye göre entegre etmeli; kullanılmıyorsa zorla projeye eklememeli.

## Önemli

Bu paket mevcut repoyu görmeden hazırlandı. Bu nedenle AI Studio önce gerçek framework, klasör yapısı, mevcut oyun mantığı, asset yolları ve build/test komutlarını tespit etmelidir. Var olan çalışan mimariyi değiştirmek yasaktır.
