# Changelog

## Unreleased
- Added Lucky Shop AI Studio project contract and implementation guidance.
- Added reusable slot reel motion helper.
- No existing game source files have been modified by this kit.
