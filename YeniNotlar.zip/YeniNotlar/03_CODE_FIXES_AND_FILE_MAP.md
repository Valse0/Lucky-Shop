# 03 — Code Fixes and File Map

The file names below come from the previous repository inspection. Re-open the current source and verify exact function/component names before editing. Line numbers are intentionally omitted because they can drift.

## 1. `src/game/slotEngine.ts` — payout and result correctness

### Total BET correction
- Locate the payline payout calculation (previously observed near the `Math.max(1, Math.round(bet * multiplier))` expression).
- Ensure `bet` is interpreted as total spin stake, not per-line stake.
- Allocate stake across all active paylines and aggregate payout safely.
- Remove any artificial minimum payout that causes a winning line to pay more than its allocated stake warrants.
- Preserve the existing grid generation, symbol rules, payline definitions, and outcome structure unless a change is necessary for correctness.
- Keep random generation injectable or otherwise testable if feasible, without changing production behavior.

### Special outcomes
- Verify Crown Wild is active only under the intended Royal Mode rule.
- Verify Chest Scatter and Diamond rewards.
- Preserve simultaneous eligible bonus rewards unless source/design proves otherwise.
- Ensure result data can distinguish line wins from bonus rewards if that improves UI clarity.

## 2. `src/App.tsx` — spin, bonus, and reset flow

### Spin deduction
- Verify the selected total BET is deducted exactly once per accepted spin.
- Prevent negative Gold and prevent starting a spin when the player cannot afford the total BET.
- Ensure the final result uses the same BET value that was charged at spin start; do not read a later mutable selection.

### Daily Bonus idempotency
Previously identified area: Daily Bonus claim handler around the `dailyBonusReady` check.
- A simple state check followed by asynchronous/state updates may allow rapid duplicate claims.
- Make claim processing atomic/idempotent using a synchronous guard or a state transition that cannot be entered twice.
- Persist the claim date/state consistently.
- Test rapid repeated invocation and reload behavior.
- Do not award the same day's bonus twice.

### Reset while spinning
- Disable or reject Reset Progress while a spin is in progress.
- Prefer the simple UI/action guard over complex animation cancellation.
- Ensure no pending spin result can overwrite a newly reset save.
- If the app already has a robust cancellation mechanism, it may be used, but test it end-to-end.

## 3. `src/game/storage.ts` — safe save validation and migration

Previously identified areas include load/parse and schema version handling.
- Validate parsed data before trusting it.
- Validate at minimum: schema version, Gold/Gems, selected BET against allowed options, shop level, player level/XP, symbol IDs in last grid, statistics, settings booleans, mission state, and spin history entries.
- Reject malformed individual fields safely rather than trusting arbitrary localStorage content.
- Handle known older schema versions through explicit migrations.
- For unknown/newer schemas, do not overwrite the original stored data with a fresh save.
- Preserve a recoverable backup of the raw save before migration when practical.
- If migration cannot be performed safely, fail non-destructively: retain the original raw data and report the issue; do not silently reset progress.
- Keep storage key compatibility unless a migration explicitly requires a change.

## 4. `src/game/missions.ts` and mission update call sites

Previously identified mismatch:
- “Happy Customers” appears to require 3 payline wins, while the counter may increment for any `totalWin > 0`, potentially including Scatter-only outcomes.
- Decide based on the existing mission label and intended game behavior:
  - If it means payline wins, count qualifying payline wins only.
  - If it means any profitable spin, update the mission wording to “winning spins” or equivalent.
- Keep mission progress and its description consistent.
- Test scatter-only and line-win cases separately.

## 5. `src/components/GameModals.tsx` — paytable and modal behavior

- Explain Crown Wild behavior in Royal Mode.
- Explain Chest Scatter trigger/reward.
- Explain Diamond-to-Gem reward rule.
- Explain whether Chest and Diamond rewards can stack on one spin.
- Ensure Royal Slots locked/unlocked visuals match the actual unlock state.
- Do not change unrelated modal layout or navigation.

## 6. `src/components/SlotMachine.tsx` and `src/slot/slotMotion.css`

- Preserve the existing reel motion and left-to-right stop order.
- Review existing `reel-stop-sparkle-v3.webp` and `.ls-reel-sparkle` definitions; use them only if they are appropriate and already available.
- Add restrained reel-stop sparkle and winning-symbol emphasis.
- Ensure big wins receive stronger but brief feedback than ordinary wins.
- Respect reduced-motion preferences.
- Prevent a second spin while the first spin is resolving.
- Avoid expensive continuous effects that degrade mobile performance.

## 7. `src/game/config.ts`

- Preserve existing symbol IDs and payline definitions.
- Keep all symbol weights and payout multipliers in one authoritative configuration where possible.
- Make mode-specific behavior explicit.
- Do not rebalance symbol weights or payout multipliers without simulation evidence and a documented reason.

## 8. `src/game/assets.ts`

- Keep the asset registry authoritative and consistent.
- Compare imported assets against the manifest.
- Previous inspection found a mismatch between the manifest and imports; re-count against the current repository rather than trusting an old count.
- Identify imported-but-unused and present-but-unimported assets.
- Do not delete any file. Report candidates for later cleanup separately.

## 9. Tests

Extend the existing `src/game/__tests__/slotEngine.test.ts` or the current test structure. Required cases are listed in `05_TEST_AND_ACCEPTANCE_CRITERIA.md`.
