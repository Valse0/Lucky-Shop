# 06 — Safe Implementation Workflow

## Phase 0: Repository reconnaissance
- Inspect branch, working tree, package manager, scripts, and current source.
- Read the current README, changelog, game design docs, and agent instructions if present.
- Verify the exact file structure and all asset archives.
- Record the current version and baseline tests/build status.
- Do not make changes until this baseline is understood.

## Phase 1: Tests and economy model
- Add tests for current behavior where needed.
- Implement total-BET accounting in a focused change.
- Add deterministic tests for one-line and multi-line wins, rounding, bonus interactions, and insufficient funds.
- Build a reproducible simulation harness.
- Report Normal and Royal metrics before proposing any numerical balancing changes.

## Phase 2: Safety fixes
- Make Daily Bonus claims idempotent.
- Prevent reset during active spin.
- Add safe save validation and explicit migrations.
- Correct mission counting/wording.
- Keep changes separate and reviewable.

## Phase 3: Visual polish
- Preserve the current visual identity and assets.
- Improve cabinet/control cohesion.
- Fix Royal Slots lock state.
- Add shop-tier visual progression using existing assets where possible.
- Complete appropriate reel-stop/win effects.
- Verify reduced motion and mobile performance.

## Phase 4: Validation
- Run tests, build, lint/typecheck where configured.
- Run economy simulations with reproducible settings.
- Test existing save data and migration paths.
- Inspect all main screens and modals at mobile portrait sizes.
- Compare before/after screenshots.

## Phase 5: Report
Provide a concise but complete implementation report using the acceptance checklist.

## Non-negotiable preservation rules
- Never delete the existing large asset ZIP archives.
- Never delete assets merely because they are unused.
- Never reset or overwrite player progress as a shortcut.
- Never replace working mechanics without a requirement.
- Never perform a broad refactor as a side effect.
- Never silently change economy numbers without simulation evidence.
- Keep changes focused, traceable, and reversible.
