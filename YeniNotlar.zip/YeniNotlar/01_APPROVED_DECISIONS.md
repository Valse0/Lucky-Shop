# 01 — Approved Product Decisions

These decisions were explicitly approved and should be treated as the implementation brief.

## 1. Betting model: TOTAL

The displayed BET amount is the **total cost of one spin across all 9 paylines**, not the stake for each individual line.

- Deduct the selected BET exactly once when a spin is accepted.
- All 9 paylines are evaluated.
- The total bet must be allocated consistently across the 9 lines for payout calculations.
- The player-facing BET control and help text must make the meaning clear.
- Do not silently change the displayed BET values or spin cost without checking the existing UI and economy.

If the current engine has integer-only payouts and the total bet cannot be divided evenly by 9, choose and document a deterministic allocation method that avoids creating or destroying value through rounding. Prefer integer-safe arithmetic (for example, calculate each line's contribution using a consistent numerator/denominator method and round only at a defined final stage). Add tests for every rounding boundary.

## 2. Code fixes: YES

Implement the confirmed correctness and safety fixes. Preserve existing player progress and working gameplay.

Priority fixes:
- Prevent duplicate Daily Bonus claims.
- Prevent Reset Progress while a spin is resolving, or otherwise make cancellation/reset fully safe. The preferred simple solution is to disable reset during an active spin.
- Validate loaded save data and handle schema changes with safe migrations.
- Align mission counters and descriptions with the actual events they count.
- Make the paytable explain all active special-symbol rules.

## 3. Visual direction: PRESERVE

Retain the existing visual identity:
- Cat mascot and Lucky Shop sign.
- Existing symbol family and recognizable symbol designs.
- Warm fantasy-town setting and current color identity.
- Current portrait layout and core screen hierarchy.

Improve polish and cohesion:
- Make the slot cabinet, reel area, and BET/SPIN/WIN controls feel like one integrated machine.
- Improve depth, lighting, framing, and hierarchy without replacing the identity.
- Give shop tiers a visible sense of progression.
- Correct locked/unlocked Royal Slots presentation.
- Complete reel-stop and win feedback where existing assets/styles support it.

## 4. Economy personality

### Normal Mode — Balanced
The default mode should provide a sustainable mix of wins and losses. Small and medium wins should create satisfying feedback, while Gold management remains meaningful. Avoid both constant losses that block play and excessive payouts that make progression meaningless.

### Royal Mode — Rewarding
Royal Mode should offer a noticeably higher reward ceiling and more exciting special-symbol interactions than Normal Mode. It must still have meaningful risk; “rewarding” does not mean every spin wins or that Gold can grow without control.

Royal Mode's Crown Wild behavior and special-symbol rules must be explicit in code, tests, and player-facing help.

## 5. Not approved / out of scope
- No wholesale visual redesign.
- No framework migration or full rewrite.
- No backend/API requirement.
- No deleting or replacing source assets without approval.
- No save wipe or forced new-game migration.
- No invented RTP target. Numerical RTP targets must be derived from reproducible simulation and reviewed separately.
