# 02 — Economy and BET Specification

## A. Meaning of BET

The BET value displayed in the game is the total stake for a single spin over all 9 paylines.

Example, if the selected total BET is 90 Gold:
- The player pays 90 Gold once.
- All 9 paylines are active and evaluated.
- The payout contribution of each line is based on its share of the 90 Gold total.
- The player must not be charged 90 Gold per line (which would cost 810 Gold).

The UI must use clear wording such as “Total bet per spin” wherever ambiguity is likely.

## B. Payout calculation

Inspect `src/game/slotEngine.ts` and the caller in `src/App.tsx` before changing formulas.

The current implementation was previously identified as calculating a payout for each winning payline using the full BET (`Math.max(1, Math.round(bet * multiplier))`), while the app deducts BET once. That can multiply the intended return when multiple lines win.

Replace this with a coherent total-stake model:
1. Establish the exact set of active paylines (currently 9, unless the repository proves otherwise).
2. Establish each line's stake from the total BET.
3. Calculate each winning line from its allocated stake and its multiplier.
4. Aggregate line payouts and bonus rewards using a clearly documented rule.
5. Deduct the total BET exactly once.
6. Keep bonus rewards (e.g. scatter/chest and diamond rewards) distinct from line payouts in the result model where practical, so the UI and tests can explain them.

### Integer and rounding requirements
- Gold values should remain integer-safe if the save/economy uses integers.
- Do not independently round every line in a way that creates an unintended minimum payout or inflates total returns.
- Define one deterministic rounding rule and test it.
- If equal division is impossible for some BET values, distribute remainder units deterministically across paylines or use numerator/denominator arithmetic and round at the aggregate boundary. Do not discard or duplicate stake value.
- Preserve existing BET options unless there is a demonstrated reason and explicit approval to change them.

## C. Mode balance

### Normal Mode: Balanced
Balance should be evaluated over many spins, not inferred from a few example outcomes.
Measure at least:
- RTP / return ratio.
- Hit frequency (percentage of spins with any payout).
- Average payout per spin.
- Distribution of zero-win, small-win, medium-win, and large-win outcomes.
- Expected net Gold change per spin.
- Frequency and value of bonus rewards.

### Royal Mode: Rewarding
Royal Mode should have a higher reward ceiling and stronger special-symbol excitement than Normal Mode. Measure the same metrics as Normal Mode, and compare them directly.

Do not make Royal Mode risk-free. Its higher potential should be balanced by the actual spin cost, symbol probabilities, and payout distribution.

### No arbitrary numerical target
Do not hardcode an invented RTP percentage merely to satisfy this brief. First:
- Reproduce the current probability model from `config.ts` and `slotEngine.ts`.
- Build or update a deterministic/reproducible simulation script or test harness.
- Run a sufficiently large sample with a fixed seed or otherwise reproducible random source.
- Report the sample size, seed/method, assumptions, mode settings, and results.
- Propose numerical targets separately for review if balancing requires changing probabilities or multipliers.

If no simulation tooling exists, add a small isolated analysis script/test utility that does not ship in the production bundle. Do not introduce runtime dependencies solely for simulation.

## D. Special rewards and rule consistency

Verify and document:
- Whether Crown is Wild in Royal Mode and not Wild in Normal Mode.
- How Chest Scatter triggers and pays.
- How Diamonds award Gems (previous analysis found 3 Diamonds = 2 Gems, 4 = 3, 5 = 4; verify this against current source before changing).
- Whether Chest and Diamond rewards can occur on the same spin and stack.
- Whether shop-level payout bonuses apply to line payouts, bonus rewards, or both.
- Whether any multiplier is additive or multiplicative.

The paytable, result feedback, and code must agree exactly.

## E. Gold and progression economy

Do not redesign the full progression economy in this task. Audit the existing:
- Starting Gold.
- BET options and affordability.
- Daily Bonus Gold/Gems.
- Shop tier costs and bonuses.
- Level/XP progression.
- Debt or failed-day behavior, if present in the current implementation.

Flag any unsustainable loop, dead-end, or mismatch. Make only changes required for the approved total-BET correction and confirmed correctness bugs. Do not invent new rewards, prices, or debt rules without approval.

## F. Royal Mode comparison

Royal Mode should feel more rewarding through a combination of:
- Higher potential outcomes.
- Clear Crown Wild explanation and visual feedback.
- More impactful big-win feedback.
- A distinct but consistent presentation.

Do not achieve this solely by multiplying every payout indiscriminately. Use simulation and outcome distribution to avoid runaway Gold inflation.
