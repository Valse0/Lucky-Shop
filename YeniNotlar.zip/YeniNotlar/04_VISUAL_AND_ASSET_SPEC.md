# 04 — Visual and Asset Specification

## A. Visual objective

Bring the current implementation closer to the supplied Lucky Shop reference while preserving the existing game's identity. This is a refinement pass, not a new art direction.

Preserve:
- Cat mascot.
- Lucky Shop sign and shop façade.
- Warm fantasy-town setting.
- Existing recognizable slot symbols.
- Current palette and portrait-first composition.
- Existing core navigation and gameplay hierarchy.

Avoid:
- Childish, flat, generic UI.
- Unnecessary glossy gradients on every surface.
- Replacing the mascot, symbols, or brand identity.
- Rebuilding the whole screen from scratch.
- Adding decorative clutter that competes with the reels and Spin action.

## B. Main screen priorities

### 1. Slot cabinet cohesion
The cabinet, reels, BET controls, SPIN button, and WIN display should read as one designed machine:
- Align outer frame and lower control base.
- Use consistent material language (wood/gold/painted metal as appropriate to current art).
- Ensure spacing, shadows, highlights, and edge treatments are coherent.
- Keep the reels as the visual focal point.
- Keep BET readable and the SPIN action prominent.

### 2. Background
The current town background was previously assessed as soft/blurred relative to the reference.
- Inspect the actual current background asset and screenshots.
- Improve perceived depth and clarity only if it can be done without damaging the foreground contrast.
- Do not blindly sharpen or replace the background.
- Preserve readability of the game UI.

### 3. Shop tier progression
There are 7 shop tiers in the previously inspected configuration.
- Make progression visually apparent across tiers using existing assets and layered treatments where possible.
- Higher tiers should feel more developed and valuable.
- Do not create seven entirely new illustrations if existing art can be composed or adapted.
- Do not change tier unlock costs or progression rules as part of visual work.

### 4. Royal Slots locked/unlocked state
Previously, the lock graphic appeared to be baked into the Royal Slots artwork, causing it to remain visible even when unlocked.
- Inspect the actual asset.
- If lock is baked into the image, use a clean unlocked-state composition or separate overlay so the lock disappears when unlocked.
- Do not distort or crop the base artwork to hide the lock if it harms quality.
- Test both locked and unlocked states.

### 5. Motion and feedback
- Use reel-stop sparkle only where it supports clarity.
- Make winning symbols easy to identify.
- Ordinary wins should be restrained; major wins can be more celebratory.
- Avoid excessive screen shake, flashing, or long blocking animations.
- Honor `prefers-reduced-motion`.
- Keep animations performant on mobile browsers.

## C. Asset inventory and preservation

Previously inspected asset registry: `src/game/assets.ts`.
Previously noted files included:
- `main-town-v3.webp`
- `reel-background-v3.webp`
- `bet-panel-v3.webp`
- `reel-stop-sparkle-v3.webp`
- `parchment-panel-v3.webp`
- `key-v3.webp`
- `potion-v3.webp`
- `coin-v3.webp`
- `horseshoe-v3.webp`

These are investigation hints only. Verify exact filenames and current usage.

Rules:
1. Do not delete or overwrite any existing asset.
2. Do not delete source asset ZIP archives, including large ZIPs in the repository.
3. Do not treat an unimported asset as disposable.
4. Record each asset as: imported/used, imported/unused, present/unimported, or missing reference.
5. Keep asset paths centralized through the existing registry where practical.
6. Update the manifest if needed, but preserve existing entries and metadata unless clearly obsolete and documented.
7. Do not copy large source ZIP files into the production bundle.

## D. Fonts
The current HTML was previously observed loading Google Fonts with system fallbacks.
- Keep current font behavior unless the project already has a clear offline-font strategy.
- Do not add large font files or dependencies as part of this task without a demonstrated benefit.

## E. Responsive behavior
- Keep portrait 9:16 as the primary target.
- Verify common mobile viewport sizes and safe areas.
- Ensure the Spin control, BET control, and navigation remain reachable and legible.
- Avoid layout overflow and clipped modal content.
