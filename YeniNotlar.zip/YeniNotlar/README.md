# Lucky Shop — Implementation Notes

This archive contains implementation instructions only. It does **not** contain game source code, replacement assets, or modified project files.

## Purpose
Apply the approved design and engineering decisions to the existing Lucky Shop repository. Read these documents before changing code.

## Approved decisions
- BET model: **total bet per spin**, shared across all 9 paylines.
- Code fixes: **implement the identified fixes**, while preserving existing player progress and working mechanics.
- Visual direction: **preserve the current Lucky Shop identity**; improve cohesion and finish rather than redesigning the game.
- Normal Mode economy: **Balanced**.
- Royal Mode economy: **Rewarding**, with higher upside and risk than Normal Mode, not guaranteed wins.

## Required working rules
1. Inspect the current repository before editing. The repository is the source of truth; names and line numbers in these notes are navigation hints, not permission to overwrite unrelated code.
2. Make focused, incremental changes. Do not rewrite the app, change frameworks, or refactor large areas unless strictly required.
3. Preserve current gameplay, player data, existing asset files, and source asset archives.
4. Never delete assets or source ZIP archives merely because they appear unused. Report usage first.
5. Do not reset, replace, or silently migrate player saves in a destructive way.
6. Do not claim a build or test passed unless it was actually run and the output was checked.
7. At the end, provide a file-by-file change report, tests/build results, known limitations, and any manual verification steps.

## Document map
- `01_APPROVED_DECISIONS.md` — binding product decisions.
- `02_ECONOMY_AND_BET_SPEC.md` — total-BET model and economy requirements.
- `03_CODE_FIXES_AND_FILE_MAP.md` — implementation work by source area.
- `04_VISUAL_AND_ASSET_SPEC.md` — visual direction and asset handling.
- `05_TEST_AND_ACCEPTANCE_CRITERIA.md` — required tests and completion checks.
- `06_SAFE_WORKFLOW.md` — implementation sequence and preservation rules.

## Scope boundary
Implement the approved changes and necessary supporting tests. Do not introduce new gameplay systems, monetization, backend services, analytics, or account systems. If a requirement cannot be implemented safely from the repository as it exists, stop that part and explain the blocker rather than guessing.
