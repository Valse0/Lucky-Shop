# 05 — Test and Acceptance Criteria

A task is complete only when the relevant checks pass or any blocker is clearly reported.

## A. BET and payout tests

- A spin deducts the selected total BET exactly once.
- BET is not multiplied by the number of paylines.
- All 9 paylines are evaluated.
- A single winning line pays from its allocated share of total BET.
- Multiple winning lines aggregate correctly without each receiving the full total BET.
- Rounding behavior is deterministic and does not inflate payouts.
- Insufficient Gold prevents a spin.
- A BET selection change during animation cannot alter the stake used for the active spin.
- Normal and Royal Mode payout rules are tested independently.

## B. Special-symbol tests

- Crown is Wild in Royal Mode if that is the configured rule.
- Crown is not accidentally Wild in Normal Mode.
- Chest Scatter trigger and reward are correct.
- Diamond reward thresholds are correct.
- Chest and Diamond rewards stack or do not stack exactly as documented.
- Bonus rewards are not accidentally counted as payline wins.
- Paytable text matches the implemented rules.

## C. Economy simulation

Provide reproducible simulation results for both modes:
- Sample size.
- Seed or reproducibility method.
- Mode configuration.
- RTP / return ratio.
- Hit frequency.
- Average payout.
- Zero-win and payout-size distribution.
- Expected net Gold change per spin.
- Bonus reward frequency.

Simulation is an analysis tool, not a substitute for unit tests. Do not present an old estimate as a freshly verified result.

## D. Daily Bonus tests

- First claim on an eligible day succeeds.
- Repeated rapid claim attempts award only once.
- Reloading after a claim does not allow a second claim on the same day.
- Day rollover follows the existing date/time policy.
- Gold and Gem rewards are applied atomically.

## E. Reset and spin tests

- Reset is unavailable while a spin is active.
- No pending result can overwrite a reset save.
- A normal reset still works when no spin is active.
- Reset confirmation behavior remains intact.

## F. Save-data tests

- Valid current save loads unchanged.
- Known older save migrates while preserving progress.
- Invalid individual fields are handled safely.
- Unknown/newer schema does not cause silent save replacement.
- Raw original save remains recoverable if migration fails.
- No test or migration silently resets player progress.

## G. Missions and UI tests

- Mission counters match their labels.
- Scatter-only results do not count as payline wins unless mission wording explicitly says any winning spin.
- Paytable explains all active special-symbol rules.
- Royal Slots lock state is correct before and after unlock.
- Reduced-motion preference is honored.

## H. Build and project checks

Run the repository's actual scripts, after inspecting `package.json`:
- Install dependencies using the package manager and lockfile already in the repo.
- Run tests.
- Run production build.
- Run lint/typecheck if configured.

Do not replace the package manager or lockfile. Do not claim a check passed if it was not run.

## I. Visual acceptance

Review the supplied screenshots/reference when available in the repository or task context:
- Existing identity remains recognizable.
- Cabinet and control panel feel integrated.
- Reel symbols remain crisp and colorful during idle, spinning, and stopped states.
- Shop progression is visually understandable.
- Royal Slots locked/unlocked states are distinct.
- Effects improve feedback without obscuring the board.
- Main actions fit on portrait mobile screens.

## J. Final delivery report

Return:
1. Summary of implemented changes.
2. Exact files changed.
3. Tests/build commands and real results.
4. Simulation methodology and results.
5. Assets used, unused, and untouched.
6. Save migration behavior and compatibility notes.
7. Known issues and manual test instructions.

Do not state “all complete” if any acceptance criterion remains unverified.
